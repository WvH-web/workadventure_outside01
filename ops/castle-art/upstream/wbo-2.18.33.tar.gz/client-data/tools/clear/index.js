/**
 *                        WHITEBOPHIR
 *********************************************************
 * @licstart  The following is the entire license notice for the
 *  JavaScript code in this page.
 *
 * Copyright (C) 2020  Ophir LOJKINE
 *
 *
 * The JavaScript code in this page is free software: you can
 * redistribute it and/or modify it under the terms of the GNU
 * General Public License (GNU GPL) as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option)
 * any later version.  The code is distributed WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU GPL for more details.
 *
 * As additional permission under GNU GPL version 3 section 7, you
 * may distribute non-source (e.g., minimized or compacted) forms of
 * that code without the copy of the GNU GPL normally required by
 * section 4, provided you include this license notice and a URL
 * through which recipients can access the Corresponding Source.
 *
 * @licend
 */

import { MutationType } from "../../js/mutation_type.js";
import { BOARD_CAPABILITY, TOOL_CODE_BY_ID } from "../manifest.js";

/** @import { ToolBootContext } from "../../../types/app-runtime" */
/** @typedef {ReturnType<typeof createClearMessage>} ClearMessage */
/** @typedef {ReturnType<typeof boot>} ClearToolState */

export const toolId = "clear";
const toolCode = TOOL_CODE_BY_ID[toolId];
export const oneTouch = true;
export const mouseCursor = "crosshair";
export const requiredCapability = BOARD_CAPABILITY.CLEAR;
export const liveMessageFields = /** @type {const} */ ({
  [MutationType.CLEAR]: {},
});

/** @param {ClearToolState} state */
function createClearMessage(state) {
  return {
    tool: toolCode,
    type: MutationType.CLEAR,
    id: "",
    token: state.identity.token,
  };
}

/** @param {ClearToolState} state */
function confirmClearBoard(state) {
  return state.ui.confirm({
    message: state.i18n.t("clear_confirmation_message"),
    confirmLabel: state.i18n.t("Clear"),
    cancelLabel: state.i18n.t("Cancel"),
    variant: "danger",
  });
}

/** @param {ClearToolState} state */
export function onstart(state) {
  void confirmClearBoard(state).then((confirmed) => {
    if (confirmed) state.writes.drawAndSend(createClearMessage(state));
  });
  return false;
}

/** @param {ClearToolState} state */
export function draw(state) {
  state.board.drawingArea.innerHTML = "";
}

/** @param {ToolBootContext} ctx */
export function boot(ctx) {
  return {
    board: ctx.runtime.board,
    identity: ctx.runtime.identity,
    i18n: ctx.runtime.i18n,
    ui: ctx.runtime.ui,
    writes: ctx.runtime.writes,
  };
}
